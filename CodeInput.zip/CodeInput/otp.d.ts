/* eslint-disable @typescript-eslint/no-explicit-any */
interface CredentialRequestOptions {
  otp?: any
}

interface Credential {
  code?: any
}
